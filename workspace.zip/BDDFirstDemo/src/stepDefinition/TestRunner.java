package stepDefinition;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 * This is the main running class
 * */
@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/login"}, glue= {"src/stepDefinition"})
/**
 * In feature you will provide the path of the FEATURE FILE.
 * In glue is the path of STEP DEFINITION path
 * Then run the TestRunner as Run as JUnit.
 * 
 * */
public class TestRunner {

}
